
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { description, useCase } = req.body;

  const prompt = `You are a visual branding assistant. Given a product description and use case, return Canva-style layout keywords, font pairings, a color palette, a recommended template type, and optionally a Canva link.

Product Description: ${description}
Use Case: ${useCase}

Return in this format:

### 🖼 Layout Keywords:
- [keyword1], [keyword2], [keyword3]

### 🔤 Font Pairing:
- Heading: [Font Name]
- Body: [Font Name]

### 🎨 Color Palette:
- Primary: #HEX (Name)
- Secondary: #HEX (Name)
- Accent: #HEX (Name)

### 📄 Template Suggestion:
- [Suggested Template Type]

### 🔗 Canva Template Link:
- [Optional Canva link or suggestion to create]`;

  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'google/gemini-pro',
        messages: [
          { role: 'user', content: prompt }
        ]
      })
    });

    const result = await response.json();
    const content = result.choices[0].message.content;

    const [_, layout, fonts, colors, template, link] = content.split(/### [^:]+:/);

    return res.status(200).json({
      layout: layout?.trim() || '',
      fonts: fonts?.trim() || '',
      colors: colors?.trim() || '',
      template: template?.trim() || '',
      link: link?.trim() || ''
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to call Gemini API' });
  }
}

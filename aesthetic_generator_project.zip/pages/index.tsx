
import { useState } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function AestheticGenerator() {
  const [description, setDescription] = useState('');
  const [useCase, setUseCase] = useState('Planner');
  const [output, setOutput] = useState({ layout: '', fonts: '', colors: '', template: '', link: '' });
  const [loading, setLoading] = useState(false);

  const generateAesthetic = async () => {
    setLoading(true);
    const res = await fetch('/api/aesthetic', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ description, useCase })
    });
    const data = await res.json();
    setOutput(data);
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">🎨 Aesthetic Generator</h1>

      <Card>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Describe your product, book, or vibe..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={6}
          />

          <Select value={useCase} onValueChange={setUseCase}>
            <SelectTrigger>
              <SelectValue placeholder="Select use case" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Planner">Planner</SelectItem>
              <SelectItem value="Journal">Journal</SelectItem>
              <SelectItem value="Landing Page">Landing Page</SelectItem>
              <SelectItem value="Social Post">Social Post</SelectItem>
              <SelectItem value="Printable">Printable</SelectItem>
            </SelectContent>
          </Select>

          <Button onClick={generateAesthetic} disabled={loading}>
            {loading ? 'Generating...' : 'Generate Aesthetic'}
          </Button>

          {output.layout && (
            <div className="mt-6 space-y-4">
              <div>
                <h2 className="font-semibold">🖼 Layout Keywords</h2>
                <pre className="bg-muted p-4 rounded whitespace-pre-wrap">{output.layout}</pre>
              </div>
              <div>
                <h2 className="font-semibold">🔤 Font Pairing</h2>
                <pre className="bg-muted p-4 rounded whitespace-pre-wrap">{output.fonts}</pre>
              </div>
              <div>
                <h2 className="font-semibold">🎨 Color Palette</h2>
                <pre className="bg-muted p-4 rounded whitespace-pre-wrap">{output.colors}</pre>
              </div>
              <div>
                <h2 className="font-semibold">📄 Template Suggestion</h2>
                <pre className="bg-muted p-4 rounded whitespace-pre-wrap">{output.template}</pre>
              </div>
              <div>
                <h2 className="font-semibold">🔗 Canva Link</h2>
                <pre className="bg-muted p-4 rounded whitespace-pre-wrap">{output.link}</pre>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

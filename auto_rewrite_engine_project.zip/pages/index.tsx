import { useState } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';

export default function AutoRewriteEngine() {
  const [input, setInput] = useState('');
  const [mode, setMode] = useState('ADHD-friendly');
  const [output, setOutput] = useState('');
  const [explanation, setExplanation] = useState('');
  const [enhancements, setEnhancements] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRewrite = async () => {
    setLoading(true);
    const response = await fetch('/api/rewrite', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ input, mode })
    });
    const data = await response.json();
    setOutput(data.rewritten);
    setExplanation(data.explanation);
    setEnhancements(data.enhancements);
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">🔄 Claude AutoRewrite Engine</h1>

      <Card>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Paste your prompt, product blurb, or hook here..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            rows={6}
          />

          <Select value={mode} onValueChange={setMode}>
            <SelectTrigger>
              <SelectValue placeholder="Select rewrite mode" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Humor">Humor</SelectItem>
              <SelectItem value="Professional">Professional</SelectItem>
              <SelectItem value="Etsy-style">Etsy-style</SelectItem>
              <SelectItem value="TikTok">TikTok-style</SelectItem>
              <SelectItem value="Trauma-aware">Trauma-aware</SelectItem>
              <SelectItem value="ADHD-friendly">ADHD-friendly</SelectItem>
              <SelectItem value="High-authority">High-authority</SelectItem>
            </SelectContent>
          </Select>

          <Button onClick={handleRewrite} disabled={loading}>
            {loading ? 'Rewriting...' : 'Rewrite with Claude'}
          </Button>

          {output && (
            <div className="mt-6 space-y-6">
              <div>
                <h2 className="text-lg font-semibold">✨ Rewritten Output</h2>
                <pre className="bg-muted p-4 rounded whitespace-pre-wrap">{output}</pre>
                <Button onClick={() => navigator.clipboard.writeText(output)}>Copy Output</Button>
              </div>
              <div>
                <h2 className="text-lg font-semibold">🧠 What Changed & Why</h2>
                <pre className="bg-muted p-4 rounded whitespace-pre-wrap">{explanation}</pre>
              </div>
              <div>
                <h2 className="text-lg font-semibold">💡 Optional Enhancements</h2>
                <pre className="bg-muted p-4 rounded whitespace-pre-wrap">{enhancements}</pre>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

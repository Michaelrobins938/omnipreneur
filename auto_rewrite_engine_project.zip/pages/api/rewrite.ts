export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { input, mode } = req.body;

  const systemPrompt = `You are a Claude-powered AutoRewrite Engine. Rewrite the user's input for clarity, tone, and platform alignment based on the selected mode. Always return the rewritten text, an explanation of changes, and optional enhancements.`;

  const userPrompt = `
Mode: ${mode}
Scope: Full rewrite

Original Input:
"""
${input}
"""

Return your response in this format:

### ✍️ Rewritten Version:
[your rewrite here]

### 🧠 What Changed & Why:
[explanation here]

### 💡 Optional Enhancements:
[suggestions here]`;

  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'anthropic/claude-3-opus',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ]
      })
    });

    const result = await response.json();
    const content = result.choices[0].message.content;

    const [_, rewritten, explanation, enhancements] = content.split(/### [^:]+:/);

    return res.status(200).json({
      rewritten: rewritten?.trim() || '',
      explanation: explanation?.trim() || '',
      enhancements: enhancements?.trim() || ''
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to call Claude API' });
  }
}
